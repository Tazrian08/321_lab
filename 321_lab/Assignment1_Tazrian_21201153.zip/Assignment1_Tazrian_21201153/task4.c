#include <stdio.h>
#include <string.h>

int main(){
	char input[50];
	printf("Enter Email: ");
	scanf("%s",input);
	char new[]="sheba.xyz";
	char old[50]="";
	
	
	int index;
	for (int i; i<strlen(input);i++){
		if (input[i]=='@'){
			index=i;
			break;
		}
	}
	
	
	
	for (int j=index+1;j<strlen(input);j++){
		old[j-(index+1)]=input[j];
	}
	if (strcmp(new,old)==0){
		printf("Email is okay");
	} else {
		printf("Email is outdated");
	
	}



}
