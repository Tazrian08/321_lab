#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *input, *output;
    char c, prev;





    input = fopen("input.txt", "r");

    output = fopen("output.txt", "w");
 

    prev = ' ';
    while ((c = fgetc(input)) != EOF) {
        if (!(prev == ' ' && c == ' ')) {
            fputc(c, output);
        }
        prev = c;
    }

}

