#include <stdio.h>
#include <string.h>

int main(){
	char input[100];
	printf("Enter String ");
	scanf("%s",input);
	char rev[100];
	
	for (int i=strlen(input)-1,j=0; j<strlen(input); i--,j++){
		rev[j]=input[i];
	}
	rev[strlen(input)] = '\0';
	
	if (strcmp(rev,input)==0){
		printf("Palindromes");
	} else {
		printf("Not Palindromes");
	
	}


}
