#include <stdio.h>

int main(){
	
	int var1, var2;
	printf("Enter first number: ");
	scanf("%d", &var1);
	printf("Enter 2nd number: ");
	scanf("%d", &var2);
	
	if (var1>var2){
		printf("%d\n", var1 - var2);
	}
	else if (var1<var2){
		printf("%d\n", var1 + var2);
	}
	else{
		printf("%d\n", var1 * var2);
	
	}
	return 0;



}
