#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){
	char password[50];
	int lc=0,uc=0, dig=0, sp=0;
	printf("Enter Password: ");
	scanf("%s", password);
	
	for (int i=0; i< strlen(password); i++){
		if (islower(password[i])){
			lc=1;
		
		}
		else if (isupper(password[i])){
			uc=1;
		
		}
		else if (isdigit(password[i])){
			dig=1;
		
		}
		else if (password[i]=='_' || password[i]=='#' || password[i]=='@'|| password[i]=='$'){
			sp=1;
		
		}
		}
	char res[100];
	if (!lc){
		strcat(res,"Lowercase character missing, ");
	
	}
	if (!uc){
		strcat(res,"Uppercase character missing, ");
	
	}
	if (!dig){
		strcat(res,"Digit missing, ");
	
	}
	if (!sp){
		strcat(res,"Special character missing, ");
	
	}
	
	if (lc && uc && dig && sp){
		strcat(res,"Ok, ");
	
	
	}
	res[strlen(res)-2]="\0";
	printf("%s", res);




}
