#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/wait.h>

struct msg {
    long int type;
    char txt[6]; 
};

int main() {
    pid_t login;
    pid_t otp;
    pid_t mail;
    int msg_id;
    int snt;
    char buff[200];

    msg_id = msgget((key_t)51, 0666 | IPC_CREAT);

    printf("Please enter the workspace name:\n");
    fgets(buff, sizeof(buff), stdin);

    if (strcmp(buff, "cse321\n") == 0) {
        struct msg s_data;
        s_data.type = 1;
        strcpy(s_data.txt, buff);
        printf("Workspace name sent to OTP generator from login: %s", s_data.txt);
        msgsnd(msg_id, &s_data, sizeof(s_data), IPC_NOWAIT);

        otp = fork();

        if (otp == 0) {
            struct msg r_data;
            if (msgrcv(msg_id, &r_data, sizeof(r_data), 1, 0) < 0) {
                perror("msgrcv");
                exit(EXIT_FAILURE);
            }
            printf("OTP generator received workspace name from login: %s", r_data.txt);
            otp = getpid();
            r_data.type = 2;
            sprintf(r_data.txt, "%d", otp);
            msgsnd(msg_id, &r_data, sizeof(r_data), IPC_NOWAIT);
            printf("OTP sent to login from OTP generator: %s\n", r_data.txt);
            
            struct msg mail_data;
            mail_data.type = 3;
            strcpy(mail_data.txt, r_data.txt); // Sending the same OTP to mail process
            msgsnd(msg_id, &mail_data, sizeof(mail_data), IPC_NOWAIT);
            printf("OTP sent to mail from OTP generator: %s\n", mail_data.txt);
            
            mail=fork();
            
            if (mail == 0) {
                struct msg r_data_mail;
                if (msgrcv(msg_id, &r_data_mail, sizeof(r_data_mail), 3, 0) < 0) {
                    perror("msgrcv");
                    exit(EXIT_FAILURE);
                }
                printf("Mail received OTP from OTP generator: %s\n", r_data_mail.txt);
                r_data_mail.type = 4;
                msgsnd(msg_id, &r_data_mail, sizeof(r_data_mail), IPC_NOWAIT);
                printf("OTP sent to login from mail: %s\n", r_data_mail.txt);
                exit(EXIT_SUCCESS);
            } else if (mail > 0) {
                wait(NULL);
                exit(EXIT_FAILURE);
                }
            

  
        } else if (otp > 0) {
            wait(NULL);
            struct msg r_data_otp;
            if (msgrcv(msg_id, &r_data_otp, sizeof(r_data_otp), 2, 0) < 0) {
                perror("msgrcv");
                exit(EXIT_FAILURE);
            }
            printf("Login received OTP from OTP generator: %s\n", r_data_otp.txt);
            struct msg r_data_mail;
            if (msgrcv(msg_id, &r_data_mail, sizeof(r_data_mail), 4, 0) < 0) {
                perror("msgrcv");
                exit(EXIT_FAILURE);
            }
            printf("Login received OTP from mail: %s\n", r_data_mail.txt);
            
            printf("OTP Verified\n");
            msgctl(msg_id, IPC_RMID, NULL); 
            
        }
    } else {
        printf("Invalid Workspace\n");
    }
    

    return 0;
}

