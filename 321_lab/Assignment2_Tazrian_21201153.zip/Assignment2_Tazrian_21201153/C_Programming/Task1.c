#include <stdio.h>

struct Item {
    float quantity;
    float unit_price;
    };
    

int main() {
    struct Item items[3];
    int people;
    float total_bill = 0;
    float ind_bill = 0;
    
    printf("Quantity of Paratha: ");
    scanf("%f", &items[0].quantity);
    printf("Unit Price: ");
    scanf("%f",&items[0].unit_price);
    
    printf("Quantity of Vegetables: ");
    scanf("%f", &items[1].quantity);
    printf("Unit Price: ");
    scanf("%f",&items[1].unit_price);
    
    printf("Quantity of Mineral Water: ");
    scanf("%f", &items[2].quantity);
    printf("Unit Price: ");
    scanf("%f",&items[2].unit_price);
    
    printf("Number of people: ");
    scanf("%d", &people);
    
    for (int i =0; i < 3; i++){
        total_bill += items[i].quantity * items[i].unit_price ;
        } 
    
    ind_bill = total_bill / people ;    
    printf("Individual people will pay: %f tk", ind_bill);
    
    return 0;
    
    }
