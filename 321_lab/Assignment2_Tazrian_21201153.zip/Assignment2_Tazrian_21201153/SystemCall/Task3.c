#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t a, b, c, d;
    int count;
    FILE *storeFile;

    storeFile = fopen("system.txt", "r");
    fscanf(storeFile, "%d", &count);
    fclose(storeFile);
    count += 8;

    storeFile = fopen("system.txt", "w");
    fprintf(storeFile, "%d", count);
    fclose(storeFile);

    a = fork();
    b = fork();
    c = fork();

    if (a < 0 || b < 0 || c < 0) {
        printf("Failed to create Child!\n");
    } 
    else if (a == 0 || b == 0 || c == 0) {
        if (getpid() % 2 != 0) {
            d = fork();
            if (d == 0) {
                storeFile = fopen("system.txt", "r");
                fscanf(storeFile, "%d", &count);
                fclose(storeFile);

                count++;

                storeFile = fopen("system.txt", "w");
                fprintf(storeFile, "%d", count);
                fclose(storeFile);

                printf("Odd process detected\n");
            }
        }
    } 
    else {
        wait(NULL);
        printf("%d\n",count);
    }

    return 0;
}

