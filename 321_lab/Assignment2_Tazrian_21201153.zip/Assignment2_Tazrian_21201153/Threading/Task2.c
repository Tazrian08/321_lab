#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

int var=1;
void* block3(void* arg)
{
	for (int i = 1; i <= 5; i++){
	printf("Thread %d prints %d\n", arg,var);
	var++;
	}
	
}

int main()
{
	pthread_t thread [5];
	for (int i = 0; i < 5; i++)
	{
		pthread_create(&thread[i], NULL, block3, (void* )i);
		pthread_join(thread[i], NULL);
		sleep(1);
	}	
	printf("The threads have all ended");
}

